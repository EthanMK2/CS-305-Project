package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController {    
	@RequestMapping("/hash")
	public String myHash() {
		String data = "Artemis Financial Check Sum!";
		MessageDigest mesDigest = null;
		String hashValue;
		
		try {
			mesDigest = MessageDigest.getInstance("SHA-256");  // SHA-256
		} catch (NoSuchAlgorithmException error) {
			error.printStackTrace();
		}
		
		mesDigest.update(data.getBytes());
		
		byte[] messageByteArray = mesDigest.digest();
		hashValue = bytesToHex(messageByteArray);
		
		return "<p>Data String: " + data + " | Algorithm cipher: SHA-256 | " + "Checksum: "
				+ hashValue + "</p>";
	}
	
	// Convert the byte array to a string
	   public String bytesToHex(byte[] bytes) {
	       StringBuilder stringBuilder = new StringBuilder();
	       
	       for (byte hashByte : bytes) {
	           int intVal = 0xff & hashByte;
	           if (intVal < 0x10) {
	        	   stringBuilder.append('0');
	           }
	           stringBuilder.append(Integer.toHexString(intVal));
	       }
	       return stringBuilder.toString();
	   }
}
